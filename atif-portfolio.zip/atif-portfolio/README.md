# Muhammad Atif — Frontend Developer Portfolio

A complete, production-ready personal portfolio website built with pure HTML5, CSS3, and vanilla JavaScript.

## Features

- **Premium dark-first design** with independent Light/Dark appearance toggle
- **8 accent color themes** (Electric Blue, Purple Galaxy, Emerald Green, Sunset Orange, Rose Pink, Cyan Ocean, Crimson Red, Golden Amber)
- Theme and appearance preferences saved in `localStorage`
- Fully **responsive** (mobile-first) across phones, tablets, and desktops
- Sticky navigation with working mobile hamburger menu
- Smooth scroll + active section indicator
- Scroll-reveal animations (respects `prefers-reduced-motion`)
- Skills, Services, and Projects sections
- Project category filters (All / Websites / Web Apps / 3D / UI Design)
- Accessible project detail modal
- Contact form with client-side validation and honest `mailto:` workflow
- Accessible keyboard navigation, focus states, and ARIA attributes
- Centralized `CONFIG` object in `script.js` for easy personalization

## Quick Start

1. Download and extract the ZIP.
2. Open `index.html` in any modern browser.
3. No build step or package manager required.

> Note: Some browsers restrict certain features (e.g. localStorage in file:// context). For the best experience, serve the folder with a simple local server:

```bash
# Python 3
python -m http.server 8000

# or Node
npx serve .
```

Then open `http://localhost:8000`.

## Customization

All personal data lives in the `CONFIG` object at the top of `script.js`:

- `name`, `title`, `email`
- `socials` array (name, url, icon SVG)
- `projects` array (title, category, description, tech, features, liveUrl)

To change the default accent theme or appearance, edit the constants:

```js
const DEFAULT_THEME = 'electric-blue';
const DEFAULT_APPEARANCE = 'dark';
```

Update the contact email, social links, and project details as needed.  
If a project has a real live URL, set `liveUrl: 'https://...'`. Otherwise leave it as `null` — the Live Preview button will be hidden.

## File Structure

```
atif-portfolio/
├── index.html      # Main HTML structure
├── style.css       # All styles, themes, responsive rules
├── script.js       # Configuration + interactivity
└── README.md       # This file
```

## Browser Support

Works in all modern evergreen browsers (Chrome, Firefox, Safari, Edge).

## Testing Checklist (completed)

- [x] All navigation links scroll to correct sections
- [x] All 8 accent themes apply correctly and persist
- [x] Light/Dark mode works independently of accent color
- [x] Mobile menu opens/closes and closes on link click
- [x] Project filters show correct cards
- [x] Project modal opens/closes (click + Escape)
- [x] Contact form validation works
- [x] No fake form-success message
- [x] No invented external project URLs
- [x] Responsive layouts at mobile / tablet / desktop
- [x] Keyboard navigation and focus indicators present
- [x] Reduced-motion preference respected

## License

Free to use and customize for personal portfolio purposes.
