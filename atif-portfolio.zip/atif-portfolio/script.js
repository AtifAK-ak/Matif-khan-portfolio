/* ============================================
   Muhammad Atif — Portfolio Script
   ============================================ */

(function () {
  'use strict';

  /* ---------- Configuration ---------- */
  const CONFIG = {
    name: 'Muhammad Atif',
    title: 'Frontend Developer',
    email: 'muhammad.atif.dev@example.com',
    socials: [
      {
        name: 'GitHub',
        url: 'https://github.com/',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>'
      },
      {
        name: 'LinkedIn',
        url: 'https://linkedin.com/',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
      },
      {
        name: 'Twitter / X',
        url: 'https://x.com/',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'
      }
    ],
    projects: [
      {
        id: 1,
        title: 'SaaS Business Website',
        category: 'websites',
        categoryLabel: 'Website',
        description: 'A modern SaaS product website featuring clear messaging hierarchy, responsive layouts, and polished interactive elements designed for clarity and conversion.',
        tech: ['HTML5', 'CSS3', 'JavaScript', 'Responsive'],
        features: [
          'Fully responsive multi-section layout',
          'Smooth scroll and section reveal animations',
          'Accessible navigation and form patterns',
          'Optimized for performance on mid-range devices'
        ],
        liveUrl: null
      },
      {
        id: 2,
        title: 'Developer Portfolio Website',
        category: 'websites',
        categoryLabel: 'Website',
        description: 'A distinctive personal portfolio built to showcase frontend skills, projects, and services with a strong visual identity and theme customization system.',
        tech: ['HTML5', 'CSS3', 'JavaScript', 'LocalStorage'],
        features: [
          'Multi-theme accent color system',
          'Independent light/dark mode',
          'Project filtering and detail modals',
          'Accessible contact form with validation'
        ],
        liveUrl: null
      },
      {
        id: 3,
        title: 'Interactive 3D Website',
        category: '3d',
        categoryLabel: '3D Project',
        description: 'An immersive 3D web experience combining Three.js scenes with responsive UI layers to create engaging, memorable digital interactions.',
        tech: ['Three.js', 'JavaScript', 'CSS3', 'WebGL'],
        features: [
          'Interactive 3D scene with camera controls',
          'Responsive UI overlay system',
          'Graceful fallback for reduced motion',
          'Performance-conscious asset handling'
        ],
        liveUrl: null
      },
      {
        id: 4,
        title: 'Business Landing Page',
        category: 'websites',
        categoryLabel: 'Landing Page',
        description: 'A focused landing page designed for clear messaging, strong visual hierarchy, and smooth micro-interactions that guide users toward action.',
        tech: ['HTML5', 'CSS3', 'JavaScript'],
        features: [
          'Conversion-oriented section structure',
          'Subtle hover and scroll animations',
          'Mobile-first responsive design',
          'Accessible button and form patterns'
        ],
        liveUrl: null
      },
      {
        id: 5,
        title: 'Web Application Interface',
        category: 'webapps',
        categoryLabel: 'Web App',
        description: 'A clean, maintainable frontend interface for a web application emphasizing usability, consistent components, and responsive behavior across devices.',
        tech: ['HTML5', 'CSS3', 'JavaScript', 'Flexbox/Grid'],
        features: [
          'Modular component structure',
          'Consistent spacing and typography system',
          'Keyboard-accessible interactions',
          'Responsive dashboard-style layout'
        ],
        liveUrl: null
      },
      {
        id: 6,
        title: 'Mobile App UI Design',
        category: 'ui',
        categoryLabel: 'UI Design',
        description: 'Thoughtfully crafted mobile app interface designs focused on clarity, consistency, and a smooth user experience across common screen sizes.',
        tech: ['UI Design', 'Responsive', 'CSS3'],
        features: [
          'Consistent component library approach',
          'Touch-friendly interactive elements',
          'Clear visual hierarchy',
          'Dark and light appearance support'
        ],
        liveUrl: null
      }
    ]
  };

  /* ---------- DOM References ---------- */
  const header = document.getElementById('header');
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  const themeBtn = document.getElementById('themeBtn');
  const themePalette = document.getElementById('themePalette');
  const appearanceBtn = document.getElementById('appearanceBtn');
  const projectsGrid = document.getElementById('projectsGrid');
  const contactForm = document.getElementById('contactForm');
  const projectModal = document.getElementById('projectModal');
  const modalBody = document.getElementById('modalBody');
  const modalClose = document.getElementById('modalClose');
  const modalBackdrop = document.getElementById('modalBackdrop');
  const backToTop = document.getElementById('backToTop');
  const yearEl = document.getElementById('year');
  const contactEmail = document.getElementById('contactEmail');
  const socialLinks = document.getElementById('socialLinks');

  /* ---------- Theme & Appearance ---------- */
  const THEMES = [
    'electric-blue', 'purple-galaxy', 'emerald-green', 'sunset-orange',
    'rose-pink', 'cyan-ocean', 'crimson-red', 'golden-amber'
  ];
  const DEFAULT_THEME = 'electric-blue';
  const DEFAULT_APPEARANCE = 'dark';

  function getStored(key, fallback) {
    try {
      const val = localStorage.getItem(key);
      return val !== null ? val : fallback;
    } catch {
      return fallback;
    }
  }

  function setStored(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* storage unavailable */
    }
  }

  function applyTheme(theme) {
    if (!THEMES.includes(theme)) theme = DEFAULT_THEME;
    document.documentElement.setAttribute('data-theme', theme);
    setStored('portfolio-theme', theme);
    document.querySelectorAll('.theme-swatch').forEach(sw => {
      sw.classList.toggle('active', sw.dataset.theme === theme);
      sw.setAttribute('aria-pressed', sw.dataset.theme === theme ? 'true' : 'false');
    });
  }

  function applyAppearance(mode) {
    document.documentElement.setAttribute('data-appearance', mode);
    setStored('portfolio-appearance', mode);
  }

  function initTheme() {
    applyTheme(getStored('portfolio-theme', DEFAULT_THEME));
    applyAppearance(getStored('portfolio-appearance', DEFAULT_APPEARANCE));
  }

  /* ---------- Navigation ---------- */
  function closeMobileMenu() {
    navMenu.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
    navToggle.setAttribute('aria-label', 'Open menu');
  }

  function openMobileMenu() {
    navMenu.classList.add('open');
    navToggle.setAttribute('aria-expanded', 'true');
    navToggle.setAttribute('aria-label', 'Close menu');
  }

  function initNav() {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.contains('open');
      if (isOpen) closeMobileMenu();
      else openMobileMenu();
    });

    navMenu.querySelectorAll('.nav-link, .btn-nav').forEach(link => {
      link.addEventListener('click', () => {
        closeMobileMenu();
      });
    });

    document.addEventListener('click', (e) => {
      if (!navMenu.contains(e.target) && !navToggle.contains(e.target) && navMenu.classList.contains('open')) {
        closeMobileMenu();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && navMenu.classList.contains('open')) {
        closeMobileMenu();
        navToggle.focus();
      }
    });
  }

  /* ---------- Active Section Indicator ---------- */
  function initActiveNav() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    function updateActive() {
      const scrollY = window.scrollY + 100;
      let current = '';
      sections.forEach(sec => {
        if (scrollY >= sec.offsetTop) current = sec.id;
      });
      navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === `#${current}`);
      });
    }

    window.addEventListener('scroll', updateActive, { passive: true });
    updateActive();
  }

  /* ---------- Header Scroll ---------- */
  function initHeaderScroll() {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 20);
      backToTop.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
  }

  /* ---------- Theme Selector ---------- */
  function initThemeSelector() {
    themeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isHidden = themePalette.hidden;
      themePalette.hidden = !isHidden;
      themeBtn.setAttribute('aria-expanded', String(isHidden));
    });

    document.querySelectorAll('.theme-swatch').forEach(sw => {
      sw.addEventListener('click', () => {
        applyTheme(sw.dataset.theme);
        themePalette.hidden = true;
        themeBtn.setAttribute('aria-expanded', 'false');
      });
    });

    document.addEventListener('click', (e) => {
      if (!themePalette.contains(e.target) && !themeBtn.contains(e.target)) {
        themePalette.hidden = true;
        themeBtn.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !themePalette.hidden) {
        themePalette.hidden = true;
        themeBtn.setAttribute('aria-expanded', 'false');
        themeBtn.focus();
      }
    });
  }

  /* ---------- Appearance Toggle ---------- */
  function initAppearance() {
    appearanceBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-appearance') || 'dark';
      const next = current === 'dark' ? 'light' : 'dark';
      applyAppearance(next);
    });
  }

  /* ---------- Projects ---------- */
  function renderProjects(filter = 'all') {
    projectsGrid.innerHTML = '';
    const filtered = filter === 'all'
      ? CONFIG.projects
      : CONFIG.projects.filter(p => p.category === filter);

    filtered.forEach(project => {
      const card = document.createElement('article');
      card.className = 'project-card reveal';
      card.dataset.category = project.category;

      const liveBtn = project.liveUrl
        ? `<a href="${project.liveUrl}" class="btn btn-secondary" target="_blank" rel="noopener noreferrer">Live Preview</a>`
        : '';

      card.innerHTML = `
        <div class="project-thumb">
          <span class="project-thumb-art" aria-hidden="true">${project.title.charAt(0)}</span>
        </div>
        <div class="project-body">
          <span class="project-category">${project.categoryLabel}</span>
          <h3 class="project-title">${project.title}</h3>
          <p class="project-desc">${project.description}</p>
          <div class="project-tech">
            ${project.tech.map(t => `<span>${t}</span>`).join('')}
          </div>
          <div class="project-actions">
            ${liveBtn}
            <button class="btn btn-primary view-details-btn" data-id="${project.id}">View Details</button>
          </div>
        </div>
      `;
      projectsGrid.appendChild(card);
    });

    // Re-observe for reveal
    observeReveals();
  }

  function initFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        renderProjects(btn.dataset.filter);
      });
    });
  }

  /* ---------- Project Modal ---------- */
  let lastFocusedElement = null;

  function openModal(projectId) {
    const project = CONFIG.projects.find(p => p.id === Number(projectId));
    if (!project) return;

    lastFocusedElement = document.activeElement;

    modalBody.innerHTML = `
      <span class="modal-category">${project.categoryLabel}</span>
      <h3 id="modalTitle">${project.title}</h3>
      <p>${project.description}</p>
      <div class="modal-tech">
        ${project.tech.map(t => `<span>${t}</span>`).join('')}
      </div>
      <div class="modal-features">
        <h4>Key Features</h4>
        <ul>
          ${project.features.map(f => `<li>${f}</li>`).join('')}
        </ul>
      </div>
      ${project.liveUrl
        ? `<a href="${project.liveUrl}" class="btn btn-primary" target="_blank" rel="noopener noreferrer">View Live Preview</a>`
        : '<p style="color:var(--text-muted);font-size:0.9rem;">Live preview is not available for this project.</p>'
      }
    `;

    projectModal.hidden = false;
    document.body.style.overflow = 'hidden';
    modalClose.focus();
  }

  function closeModal() {
    projectModal.hidden = true;
    document.body.style.overflow = '';
    if (lastFocusedElement) lastFocusedElement.focus();
  }

  function initModal() {
    projectsGrid.addEventListener('click', (e) => {
      const btn = e.target.closest('.view-details-btn');
      if (btn) openModal(btn.dataset.id);
    });

    modalClose.addEventListener('click', closeModal);
    modalBackdrop.addEventListener('click', closeModal);

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !projectModal.hidden) {
        closeModal();
      }
    });
  }

  /* ---------- Contact Form ---------- */
  function initContactForm() {
    // Set email link
    if (contactEmail) {
      contactEmail.href = `mailto:${CONFIG.email}`;
      contactEmail.querySelector('span').textContent = CONFIG.email;
    }

    // Social links
    if (socialLinks) {
      socialLinks.innerHTML = CONFIG.socials.map(s => `
        <a href="${s.url}" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="${s.name}">
          ${s.icon}
        </a>
      `).join('');
    }

    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const formNote = document.getElementById('formNote');
      const name = document.getElementById('name');
      const email = document.getElementById('email');
      const subject = document.getElementById('subject');
      const message = document.getElementById('message');

      // Clear previous errors
      ['nameError', 'emailError', 'subjectError', 'messageError'].forEach(id => {
        document.getElementById(id).textContent = '';
      });
      formNote.textContent = '';
      formNote.className = 'form-note';

      let valid = true;

      if (!name.value.trim()) {
        document.getElementById('nameError').textContent = 'Name is required.';
        valid = false;
      }
      if (!email.value.trim()) {
        document.getElementById('emailError').textContent = 'Email is required.';
        valid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        valid = false;
      }
      if (!subject.value.trim()) {
        document.getElementById('subjectError').textContent = 'Subject is required.';
        valid = false;
      }
      if (!message.value.trim()) {
        document.getElementById('messageError').textContent = 'Message is required.';
        valid = false;
      }

      if (!valid) return;

      // Honest mailto workflow — no fake success
      const mailto = `mailto:${CONFIG.email}?subject=${encodeURIComponent(subject.value.trim())}&body=${encodeURIComponent(
        `Name: ${name.value.trim()}\nEmail: ${email.value.trim()}\n\n${message.value.trim()}`
      )}`;

      formNote.textContent = 'Opening your email client to send the message…';
      formNote.className = 'form-note success';

      // Open mailto
      window.location.href = mailto;

      // Reset form after short delay
      setTimeout(() => {
        contactForm.reset();
        formNote.textContent = 'If your email client did not open, please send your message directly to ' + CONFIG.email;
        formNote.className = 'form-note';
      }, 2000);
    });
  }

  /* ---------- Scroll Reveal ---------- */
  let observer;

  function observeReveals() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
      return;
    }
    if (!observer) {
      observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    }
    document.querySelectorAll('.reveal:not(.visible)').forEach(el => observer.observe(el));
  }

  function initReveals() {
    // Add reveal class to major sections content
    document.querySelectorAll('.about-content, .about-card, .skill-category, .service-card, .section-header').forEach(el => {
      el.classList.add('reveal');
    });
    observeReveals();
  }

  /* ---------- Back to Top ---------- */
  function initBackToTop() {
    backToTop.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------- Year ---------- */
  function setYear() {
    if (yearEl) yearEl.textContent = new Date().getFullYear();
  }

  /* ---------- Init ---------- */
  function init() {
    initTheme();
    initNav();
    initActiveNav();
    initHeaderScroll();
    initThemeSelector();
    initAppearance();
    renderProjects();
    initFilters();
    initModal();
    initContactForm();
    initReveals();
    initBackToTop();
    setYear();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
